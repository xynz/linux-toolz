#ifndef _H_SYSLXCOM_
#define _H_SYSLXCOM_

/* Rufus placeholder */

#endif
