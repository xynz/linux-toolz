feat: description

closes issue: #featurediscussion

test: unit and integration

unit test?

integration test in (default in `tests`, otherwise explain concise)

refactor: affects other tests or data structures?

docs: documented?

perf: performance impact?
