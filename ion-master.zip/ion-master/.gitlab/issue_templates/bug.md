bug: description

expect: outcome description

related: none/#issuenumber

code: input
```
shell code
```

expect: output
```
result
```

kernel: win10/win7/linux4.4/linux5.7/mac10.0/mac10.15/redox0.3.5/redox0.5.0

version: `ion --version`/`git rev-parse HEAD`

interaction: none/program list

context: additional setup/run inside terminal multiplexer etc

behavior of bash/dash/zsh/fish/oil
