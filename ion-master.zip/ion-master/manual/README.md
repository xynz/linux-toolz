# Ion Manual

This manual is meant to be generated via [mdBook](https://github.com/azerupi/mdBook). Simply
executing `mdbook build` in this directory will build all the HTML/JS/CSS files into the
**book** directory. Executing `mdbook serve` will have **mdbook** act has a web service
which can be accessed at http://localhost:3000.

At some point, Ion may provide a native builtin for quick access to reading the documentation
of the shell, similarly to what Fish does with it's own documentation. This will require
integrating **mdbook**'s library interface into Ion.
