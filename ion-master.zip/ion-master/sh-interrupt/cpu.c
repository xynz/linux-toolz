/* Eats up CPU time, never does voluntary context switch */
/* Exits on signals as usual */

int main(void)
{
  while(1);
  return 0;
}
