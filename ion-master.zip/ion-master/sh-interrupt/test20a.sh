#! ./testshell

#echo Second level is pid $$
./test20b.sh
echo Broken, exit code $?
