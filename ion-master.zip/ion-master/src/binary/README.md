# shell::binary

This module contains all of the logic associated with the shell's application. This logic
consists primarily of the REPL, script and argument executions, and word designators.